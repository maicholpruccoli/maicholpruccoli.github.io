﻿String.prototype.toDate = function() {
    return parseDate(this, "d/M/y").toDateOnly();
};

Date.prototype.getDifferenzaGiorni = function(data) {
    var diff = this - data //unit is milliseconds
    return diff = Math.round(diff / 1000 / 60 / 60 / 24) //contains days passed
};

Date.prototype.toDateOnly = function() {
    var tmp = new Date(this);
    tmp.setHours(0, 0, 0, 0);

    return tmp;
};

Date.prototype.addDays = function(days) {
    var d = new Date(this);
    d.setDate(this.getDate() + days);

    return d;
};

Date.prototype.toStringa = function() {
    return formatDate(this, "dd/MM/y")
};

$(document).ready(function() {
    passNamespace.inizializzaSearchBox();
});

var passNamespace = {
    inizializzaSearchBox: function() {
        $("#pass-container #cmbCamere").on("change", function() {
            passNamespace.visualizzaCamerePassepartout();
        });

        $("#pass-container #cmbQuantitaRiduzioni1").on("change", function() {
            passNamespace.visualizzaEtaBambini(1);
        });

        $("#pass-container #cmbQuantitaRiduzioni2").on("change", function() {
            passNamespace.visualizzaEtaBambini(2);
        });

        $("#pass-container #cmbQuantitaRiduzioni3").on("change", function() {
            passNamespace.visualizzaEtaBambini(3);
        });

        $("#pass-container #cmbQuantitaRiduzioni4").on("change", function() {
            passNamespace.visualizzaEtaBambini(4);
        });

        passNamespace.visualizzaCamerePassepartout();
        passNamespace.inizializzaDatePicker();

        var now = new Date();
        var dateNow = formatDate(now, "d/M/y");
        var dateNowPlus1 = formatDate(dateNow.toDate().addDays(1), "d/M/y");

        $("#pass-container #dataArrivo").val(dateNow);
        $("#pass-container #dataPartenza").val(dateNowPlus1);
        passNamespace.setNotti();

        var prevNotti = $("#cmbNotti").data("value", $("#cmbNotti").val());
        var prevDataArrivo = $("#dataArrivo").data("value", $("#dataArrivo").val());
        var prevDataPartenza = $("#dataPartenza").data("value", $("#dataPartenza").val());

        $("#cmbNotti").change(function(e) {
            var previousValue = $(this).data("value");

            var theValue = $(this).val();
            $(this).data("value", theValue);

            passNamespace.setDataPartenza();
        });

        $("#pass-container #btnPrenota").on("click", function(e) {
            e.preventDefault();

            var camere = [];

            var submitArray = $("#pass-container form").serializeArray();

            var camereFields = submitArray.filter(x => x.name.startsWith('camere'));

            for (var camereField of camereFields) {
                var index = camereField.name.substring(camereField.name.indexOf('[') + 1, camereField.name.indexOf(']'));
                var property = camereField.name.substring(camereField.name.indexOf('.') + 1, camereField.name.length);

                if (property.startsWith('bambini')) {
                    var propertyBambino = property.substring(property.indexOf('.') + 1, property.length);

                    var objBambino = {};
                    objBambino[propertyBambino] = +camereField.value;

                    if (camere[index] == null) {
                        var obj = { bambini: [objBambino] };
                        camere.push(obj);
                    } else {
                        if (camere[index].bambini == null) {
                            camere[index].bambini = [objBambino];
                        } else {
                            var indexBambino = property.substring(property.indexOf('[') + 1, property.indexOf(']'));

                            if (camere[index].bambini[indexBambino] == null) {
                                camere[index].bambini.push(objBambino);
                            } else {
                                camere[index].bambini[indexBambino][propertyBambino] = +camereField.value;
                            }
                        }
                    }
                } else {
                    if (camere[index] == null) {
                        var obj = {};
                        obj[property] = +camereField.value;
                        camere.push(obj);
                    } else {
                        camere[index][property] = +camereField.value;
                    }
                }
            }

            var arrivoField = submitArray.find(x => x.name == 'arrivo');
            var partenzaField = submitArray.find(x => x.name == 'partenza');
            var codicePromozioneField = submitArray.find(x => x.name == 'codicePromozione');

            var arrivoSplit = arrivoField.value.split('/');
            var partenzaSplit = partenzaField.value.split('/');

             
            window.open('https://booking.passepartout.cloud/booking?lingua=it&oidAlbergo=1000001119&arrivo=' + arrivoSplit[2] + '-' + (arrivoSplit[1].length == 2 ? arrivoSplit[1] : ('0' + arrivoSplit[1])) + '-' + (arrivoSplit[0].length == 2 ? arrivoSplit[0] : ('0' + arrivoSplit[0])) + '&partenza=' + partenzaSplit[2] + '-' + (partenzaSplit[1].length == 2 ? partenzaSplit[1] : ('0' + partenzaSplit[1])) + '-' + (partenzaSplit[0].length == 2 ? partenzaSplit[0] : ('0' + partenzaSplit[0])) + '&camere=' + JSON.stringify(camere) + (!!codicePromozioneField.value ? '&codicePromozione=' + codicePromozioneField.value : ''));
        });

        $("#dataPartenza").change(function(e) {
            var previousValue = $(this).data("value");

            var theValue = $(this).val();

            var isOk = false;

            if (theValue != "") {
                if (!passNamespace.isDataPartenzaMinoreUgualeDataArrivo()) {
                    if (passNamespace.isDataPartenzaValidaPerNotti()) {
                        passNamespace.setNotti();
                        $(this).data("value", theValue);
                        isOk = true;
                    }
                } else {
                    alert("L'arrivo deve essere minore della partenza.");
                }
            }
            if (!isOk) {
                $(this).val(previousValue);
            }
        });

        $("#dataArrivo").change(function(e) {

            var previousValue = $(this).data("value");

            var theValue = $(this).val();

            if (theValue != "") {
                if (passNamespace.isDataArrivoMinoreOggi()) {
                    $(this).val(previousValue);
                    $(this).data("value", previousValue);

                    alert("L'arrivo deve essere maggiore o uguale alla data odierna");
                } else {
                    $(this).data("value", theValue);
                    passNamespace.setDataPartenza();
                }
            }
        });
    },

    isDataArrivoMinoreOggi: function() {
        var ret = false;

        var dataArrivo = $("#dataArrivo").val().toDate();
        var today = new Date().toDateOnly();

        if (dataArrivo < today) {
            ret = true;
        }

        return ret;
    },

    isDataPartenzaMinoreUgualeDataArrivo: function() {
        var ret = false;

        var dataArrivo = $("#dataArrivo").val().toDate();
        var dataPartenza = $("#dataPartenza").val().toDate();

        if (dataPartenza.toDateOnly() <= dataArrivo.toDateOnly()) {
            ret = true;
        }

        return ret;
    },

    isDataPartenzaValidaPerNotti: function() {
        var ret = true;

        var dataArrivo = $("#dataArrivo").val().toDate();
        var dataPartenza = $("#dataPartenza").val().toDate();

        var notti = dataPartenza.getDifferenzaGiorni(dataArrivo);

        if (notti > 90) {
            ret = false;
        }

        return ret;
    },
    visualizzaCamerePassepartout: function() {
        var camere = parseInt($("#pass-container #cmbCamere").val());

        $("#pass-container .divClientiCamera").each(function(index, el) {

            if (parseInt($(el).attr("indicecamera")) > camere) {
                $(el).hide();
                $(el).find(":input").attr("disabled", "disabled");
            } else {
                $(el).show();
                $(el).find(":input").removeAttr("disabled", "disabled");
            }

        });

        passNamespace.visualizzaEtaBambini(1);
        passNamespace.visualizzaEtaBambini(2);
        passNamespace.visualizzaEtaBambini(3);
        passNamespace.visualizzaEtaBambini(4);
    },
    visualizzaEtaBambini: function(indice) {
        var bambini = parseInt($("#pass-container #cmbQuantitaRiduzioni" + indice).val());

        $("#pass-container [id^=cmbEtaBambini" + indice + "]").each(function(index, el) {

            var indicebambino = parseInt($(el).attr("indicebambino"));

            if (indicebambino > bambini) {
                $(el).hide();
                $(el).attr("disabled", "disabled");
                $("#pass-container #quantitaBambino" + indice + indicebambino).attr("disabled", "disabled");
            } else {
                $(el).show();
                $(el).removeAttr("disabled", "disabled");
                $("#pass-container #quantitaBambino" + indice + indicebambino).removeAttr("disabled", "disabled");
            }

        });

        if (bambini == 0) {
            $("#pass-container #divEtaBambini" + indice).hide();
        } else {
            $("#pass-container #divEtaBambini" + indice).show();
        }
    },

    inizializzaDatePicker: function() {
        var mesi = 1;
        $.datepicker.setDefaults($.datepicker.regional["it"]);

        $(".editorDateTime").datepicker({

            changeYear: true,
            changeMonth: true,
            buttonImage: "calendario.gif",
            gotoCurrent: true,
            buttonImageOnly: true,
            showOn: "both",
            showAnim: "fade",
            dateFormat: "dd/mm/yy",
            numberOfMonths: parseInt(mesi)
        });

        $(".editorDateTime").mask("99/99/9999");
    },

    setDataPartenza: function() {
        var dataArrivo = $("#dataArrivo").val().toDate();
        var dataPartenza = dataArrivo.addDays(parseInt($("#cmbNotti").val()));

        $("#dataPartenza").val(dataPartenza.toStringa());
        $("#dataPartenza").data("value", dataPartenza.toStringa());
    },

    setNotti: function() {
        var dataArrivo = $("#dataArrivo").val().toDate();
        var dataPartenza = $("#dataPartenza").val().toDate();

        var notti = dataPartenza.getDifferenzaGiorni(dataArrivo);

        $("#cmbNotti").val(notti);
    }
}